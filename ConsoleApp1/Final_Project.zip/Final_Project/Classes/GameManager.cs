﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project.Classes
{
    public static class GameManager
    {
        public static List<Player> ListPlayers = new List<Player>();
        public static Player CurrentPlayer;
        public static bool gameOver = false;
        private static int BattleRounds = 0;
        private static int MaxRounds = 5;

        public static void StartGame(string name)
        {
            try
            {
                GameManager.ListPlayers = DataXML.Load("HighScores.xml");
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception error : " + e.Message);
            }

            Player player = Search_Player(name);
            //Player is loaded from the file 
            if (player != null)
            {
                if (player.IsDead())
                {
                    CurrentPlayer = new Player(name, 100, 0, 0);
                }
                else
                {
                    CurrentPlayer = player;
                }
            }
            else   //Player is not found
            {
                CurrentPlayer = new Player(name, 100, 0, 0);
            }
        }
        //-------------------------------------------------------------------------------
        public static Player Search_Player(string name)
        {
            foreach (Player player in ListPlayers)
            {
                if (String.Compare(player.Name, name, true) == 0)
                {
                    return player;
                }
            }
            return null;
        }
        //-----------------------------------------------------------------------------
        public static void GameOver()
        {
            gameOver = true;
            Console.WriteLine("Game Over !");
        }
        public static void SaveGame()
        {
            CurrentPlayer.Enemy = null;
            Player player = Search_Player(CurrentPlayer.Name);
            //Player is found
            if (player != null)
            {
                if (player.Gp < CurrentPlayer.Gp)
                {
                    ListPlayers.Remove(player);// remove the existing player with lower score
                    ListPlayers.Add(CurrentPlayer);//save the player of highest score in List
                }
            }
            else   //Player is not found
            {
                ListPlayers.Add(CurrentPlayer);//save the player in List
            }
            //Save the List in XML file
            DataXML.Save("HighScores.xml", GameManager.ListPlayers);
        }
        //--------------------------------------------------------------------------------------------
        public static void StartBattle()
        {
            Console.WriteLine("You are trying to kill the enemy " + GameManager.CurrentPlayer.Enemy.Name);
            GameManager.CurrentPlayer.Attack();
            BattleRounds++;

            System.Threading.Thread.Sleep(1000);//wait for one second

            if (GameManager.CurrentPlayer.Enemy != null &&
                GameManager.CurrentPlayer.Enemy.IsDead())
            {
                Message.Danger("\nYour enemy is dead !");
                BattleRounds = 0;
                GameManager.CurrentPlayer.Enemy = null;
                GameManager.Explore();
            }
            else
            {
                Message.Danger("\nYour enemy is not dead !");

                if (BattleRounds >= MaxRounds)
                {
                    Message.Danger("\nYou panic and run away ....");
                    GameManager.CurrentPlayer.Enemy = null;
                    BattleRounds = 0;
                    GameManager.Explore();
                }
                else
                {
                    //The enemy attack the player
                    if (GameManager.CurrentPlayer.Enemy != null)
                    {
                        GameManager.CurrentPlayer.Enemy.Attack();
                        Message.Danger("\n" + GameManager.CurrentPlayer.Enemy.Name + " is attacking you ...");
                    }
                }
            }
        }
        //------------------------------------------------------------------------------------------
        public static void Explore()
        {
            Dice dice = Dice.Get_Instance();
            int random = dice.Next(0, 15);
            Console.WriteLine("\nYou are exploring ...");
            switch (random)
            {
                case 0:
                case 1:
                case 2:
                case 3:
                    Monster monster = GameFactory.CreateMonster();
                    Message.Danger(monster.Name + " approches ! Prepare for battle !");
                    //monster.SetTarget(GameManager.CurrentPlayer);
                    monster.Target = GameManager.CurrentPlayer;
                    GameManager.CurrentPlayer.Enemy = monster;
                    break;

                case 4:
                    Power magic_potion = GameFactory.CreateHealing();
                    Message.Warning("\nYou collect a Magic Potion !");
                    GameManager.CurrentPlayer.Add(magic_potion);
                    break;

                case 5:
                    Message.Warning("\nYou collect a Magic Cape !");
                    Power magic_cape = GameFactory.CreateInvisible();
                    GameManager.CurrentPlayer.Add(magic_cape);
                    break;
                case 6:
                    Message.Warning("\nYou collect a Wood Shield !");
                    Power shield = GameFactory.CreateProtect();
                    GameManager.CurrentPlayer.Add(shield);
                    break;
                case 7:
                    Message.Warning("\nYou collect a Sleepy Dust !");
                    Power magic_powder = GameFactory.CreateSleepy();
                    GameManager.CurrentPlayer.Add(magic_powder);
                    break;
                case 8:
                    Message.Warning("\nYou find a Big Rock !");
                    Weapon rock = GameFactory.CreateRock();
                    GameManager.CurrentPlayer.Update_Weapon(rock);
                    break;

                case 9:
                    Message.Warning("\nYou find a Torch !");
                    Weapon torch = GameFactory.CreateTorch();
                    GameManager.CurrentPlayer.Update_Weapon(torch);
                    break;

                case 10:
                    Message.Warning("\nYou find a Magic Sword !");
                    Weapon sword = GameFactory.CreateSword();
                    GameManager.CurrentPlayer.Update_Weapon(sword);
                    break;
                case 11:
                    //Number of Gold Pieces is Random between 20 and 99
                    int random_gp = Dice.Get_Instance().Next(50, 500);
                    Message.Warning("\nYou collect " + random_gp + " Gold Pieces !");
                    GameManager.CurrentPlayer.Gp += random_gp;
                    break;
                default:
                    Console.WriteLine("\nYou are looking for gold pieces !");
                    break;
            }
        }
    }
}
