﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProjectMaze.Classes.Entities
{
    public enum Direction  { NONE, UP, DOWN, LEFT, RIGHT}
}
