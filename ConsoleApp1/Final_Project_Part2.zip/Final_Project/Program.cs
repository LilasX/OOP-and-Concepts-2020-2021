﻿using Final_Project.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project
{
    class Program
    {
        static void Main(string[] args)
        {
           // Power obj = new Power("Magic Cape", Power_Type.Invisible);
          //  Console.WriteLine(obj.Name + " Type " + obj.Type);

          //  Console.ReadLine();
        }
    }
}
