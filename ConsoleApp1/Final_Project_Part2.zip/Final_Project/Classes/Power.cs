﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project.Classes
{
    
    public class Power
    {
        private string name;
        private Power_Type type;
        private int min_XP;

        //Constructor
        public Power(string name, Power_Type type, int min_XP)
        {
            this.name = name;
            this.type = type;
            this.min_XP = min_XP;
        }

        //Encapsulate
        public string Name { get => name; set => name = value; }
        public Power_Type Type { get => type; set => type = value; }
        public int Min_XP { get => min_XP; set => min_XP = value; }
    }
}
