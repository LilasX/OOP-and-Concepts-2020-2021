﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project.Classes
{
    public class Monster : LivingEntity
    {
        //private string name;
        //private int hp;
        private int ap;
        private Player target;

        public Monster(string name, int hp, int ap) : base(name,hp)
        {
            //this.Name = name;
            //this.Hp = hp;
            this.Ap = ap;
            //this.target = null;
        }

        public Monster() : base("Monster", 90)
        {
            this.ap = 30;
        }

        //public string Name { get => name; set => name = value; }
        //public int Hp { get => hp; set => hp = value; }
        public int Ap { get => ap; set => ap = value; }
        public Player Target { get => target; set => target = value; }

        //public bool IsDead()
        //{
        //    return this.Hp <= 0;
        //}

        //public void Receive_Damage(int damage)
        //{
        //    this.Hp -= damage;
        //    Console.WriteLine("Your enemy got hit ! The current HP of your enemy = " + this.hp);
        //}

        public override void Attack()
        {
            Console.WriteLine("The enemy " + this.Name + "is attacking you ...");
            this.Target.Receive_Damage(this.ap);
        }
    }
}
