﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project.Classes
{
    public class Player : LivingEntity
    {
        //private string name;
       //private int hp;
        private readonly int hp_max;
        private int xp;
        private int gp;
        private bool protect;
        private Monster enemy;
        private List<Power> my_powers;
        private Weapon my_weapon;

        public Player(string name, int hp, int xp, int gp) : base(name,hp)
        {
            //this.Hp = hp;
            this.hp_max = hp;
            this.xp = xp;
            this.gp = gp;
            //this.Name = name;
            this.protect = false;
            this.enemy = null;
            this.my_weapon = new Weapon("Wood Stick", 20, 25);
            this.my_powers = new List<Power>();
        }

        //public string Name { get => name; set => name = value; }
        //public int Hp { get => hp; set => hp = value; }
        public int Hp_max { get => hp_max; }
        public int Xp { get => xp; set => xp = value; }
        public int Gp { get => gp; set => gp = value; }
        public bool Protect { get => protect; set => protect = value; }
        public Monster Enemy { get => enemy; set => enemy = value; }
        public List<Power> My_powers { get => my_powers; set => my_powers = value; }
        public Weapon My_weapon { get => my_weapon; set => my_weapon = value; }

        //public bool IsDead()
        //{
        //    return this.hp <= 0;
        //}

        public void Heal()
        {
            Console.WriteLine("Your HP has been restored ! ");
            this.Hp = hp_max;
        }

        public void Hide()
        {
            Console.WriteLine("You are hidden ! You ran away ! ");
            //Explore();
        }

        public void Add(Power p)
        {
            this.my_powers.Add(p);
        }

        public Power Get_Power (Power_Type type)
        {
            for (int i = 0; i < this.my_powers.Count; i++)
            {
                Power obj = this.My_powers[i];
                if (obj.Type == type)
                {
                    this.my_powers.RemoveAt(i);
                    return obj;
                }
            }
            return null;
        }

        public void Apply_Power(Power_Type type)
        {
            Power obj_power = this.Get_Power(type);

            if (obj_power != null)
            {
                if (this.Xp >= obj_power.Min_XP)
                {
                    switch (type)
                    {
                        case Power_Type.Healing:
                            this.Heal();
                            break;

                        case Power_Type.Invisible:
                            this.Hide();
                            break;

                        case Power_Type.Protect:
                            this.Protect = true;
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Type of power nonexistent. ");
                }
            }

        }

        public override void Receive_Damage(int damage)
        {
            if (this.protect)
            {
                this.Hp -= damage / 2;
            }
            else
            {
                this.Hp -= damage;
            }
            Console.WriteLine("You have been hit ! Your current HP = " + this.Hp);
        }

        public void Update_Weapon(Weapon new_weapon)
        {
            if (this.my_weapon.Max_damage < new_weapon.Max_damage)
            {
                this.my_weapon = new_weapon;
            }
        }

        public override void Attack()
        {
            Console.WriteLine("You're attacking the enemy " + this.Enemy.Name);

            int min_damage = this.My_weapon.Min_damage;
            int max_damage = this.My_weapon.Max_damage;

            int damage = Dice.Get_Instance().Next(min_damage, max_damage + 1);
            this.Enemy.Receive_Damage(damage);
        }

        public override string ToString()
        {
            return "HP = " + this.Hp + "| Xp = " + this.Xp + "| GP = " + this.Gp;
        }
    }
}
