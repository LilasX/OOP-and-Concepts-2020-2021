﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project.Classes
{
    public class Weapon
    {
        private string name;
        private int min_damage;
        private int max_damage;

        public Weapon(string name, int min_damage, int max_damage)
        {
            this.name = name;
            this.min_damage = min_damage;
            this.max_damage = max_damage;
        }

        public string Name { get => name; set => name = value; }
        public int Min_damage { get => min_damage; set => min_damage = value; }
        public int Max_damage { get => max_damage; set => max_damage = value; }
    }
}
