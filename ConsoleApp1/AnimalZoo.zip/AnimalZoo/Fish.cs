﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalZoo
{
    class Fish : Animal
    {
        public Fish(int age, int weight, String gender) : base(age, weight, gender)
        {

        }



    }
}
